clear; close all; clc;
root    = fileparts(mfilename('fullpath'));
dataDir = fullfile(root,'data');
outDir  = fullfile(root,'results');
if ~exist(outDir,'dir'), mkdir(outDir); end

T  = readtable(fullfile(dataDir,'dalate_weather_hourly.csv'));
dt = datetime(string(T.time),'InputFormat','yyyy-MM-dd''T''HH:mm');
ta = T.temperature_2m_c;
ok = isfinite(ta); dt = dt(ok); ta = ta(ok);
dv     = dateshift(dt,'start','day');
g      = findgroups(dv);
dayDT  = splitapply(@(x) x(1), dv, g);
dayT   = splitapply(@mean, ta, g);
[~,iCold] = min(dayT); coldDay = dayDT(iCold); coldT = min(dayT);
heatSeason = (month(dayDT)>=11) | (month(dayDT)<=3);
Tavg = mean(ta); Tmax = max(ta); Tmin = min(ta);

tH = (0:0.25:24)';                                 
D  = 2*exp(-((tH-9)/2.5).^2) + 3*exp(-((tH-19)/3).^2) + 8*(tH>=2);   
t7200 = 2*3600; i7200 = find(tH*3600==t7200, 1);
preVal = D(tH*3600 < t7200); preVal = preVal(end);
tSec = [tH(1:i7200-1)*3600; t7200-0.1; t7200; tH(i7200+1:end)*3600];
D    = [D(1:i7200-1);       preVal;    D(i7200); D(i7200+1:end)];
dlmwrite(fullfile(dataDir,'steam_demand_day.csv'), [tSec D], 'precision', 6);


tPlot = (0:10:5*3600)';                            
Dp    = interp1(tSec, D, tPlot, 'linear', 0);
H_int = -0.05*cumtrapz(tPlot, Dp);                 
H_fake = lsim(tf([75 0],[30 1]), Dp, tPlot);        
H_open = H_int + H_fake;


f = figure('Visible','off','Position',[100 100 960 420]);
area(dayDT, heatSeason*40, 'FaceColor',[0.85 0.90 1.0],'EdgeColor','none'); hold on;
plot(dayDT, dayT, 'b-','LineWidth',0.8); grid on;
yline(18,'r--','供暖基准 18°C'); yline(0,'k:');
xlabel('日期','FontName','Microsoft YaHei'); ylabel('日平均气温 (°C)','FontName','Microsoft YaHei');
title(sprintf('达拉特旗 2025 年气温（年均 %.1f°C，最冷日 %s %.1f°C）', Tavg, char(coldDay,'yyyy-MM-dd'), coldT),'FontName','Microsoft YaHei');
set(gca,'FontName','Microsoft YaHei');
exportgraphics(f, fullfile(outDir,'01_dalate_temp.png')); close(f);


f = figure('Visible','off','Position',[100 100 960 420]);
plot(tSec/3600, D, 'k-','LineWidth',1.8); grid on; yline(0,'k:');
xlabel('时刻 (h)','FontName','Microsoft YaHei'); ylabel('蒸汽流量偏差 (%Dn)','FontName','Microsoft YaHei');
title('冬季典型日蒸汽扰动 D(t)：第 2 h 突增 8%（模拟负荷扰动）','FontName','Microsoft YaHei');
set(gca,'FontName','Microsoft YaHei');
exportgraphics(f, fullfile(outDir,'02_steam_demand.png')); close(f);


f = figure('Visible','off','Position',[100 100 960 420]);
plot(tPlot/3600, H_open, 'r-','LineWidth',1.6); hold on; grid on;
yline(30,'b--'); yline(-30,'b--');  
xlabel('时刻 (h)','FontName','Microsoft YaHei'); ylabel('汽包水位 (mm)','FontName','Microsoft YaHei');
title('无自动调节（开环）：蒸汽突增后水位持续下跌，约 1.3 分钟即越限','FontName','Microsoft YaHei');
legend('开环水位','安全范围 ±30mm','Location','southwest','FontName','Microsoft YaHei');
set(gca,'FontName','Microsoft YaHei');
exportgraphics(f, fullfile(outDir,'03_openloop_drift.png')); close(f);


sumFile = fullfile(outDir,'summary.txt');
oldTxt = '';
if exist(sumFile,'file'), oldTxt = fileread(sumFile); end
kSim = strfind(oldTxt, '[Simulink 仿真]');    
simPart = '';
if ~isempty(kSim), simPart = oldTxt(kSim(1):end); end

fid = fopen(sumFile,'w');
fprintf(fid,'达拉特旗 2025（Open-Meteo 爬虫采集）\n');
fprintf(fid,'逐小时记录 %d 条；年均温 %.2f°C；年极值 %.1f ~ %.1f°C\n', numel(ta), Tavg, Tmin, Tmax);
fprintf(fid,'最冷日 %s，日均 %.1f°C\n', char(coldDay,'yyyy-MM-dd'), coldT);
fprintf(fid,'供暖季(11月~3月)天数 %d 天\n', sum(heatSeason));
fprintf(fid,'扰动曲线：早/晚高峰 + 第2h蒸汽突增8%%；采样点 %d 个（含硬阶跃）\n', numel(tSec));
fprintf(fid,'开环(无调节)：突增后 %.1f mm/s 持续下跌，5 h 跌至 %.0f mm\n', 0.05*8, H_open(end));
fclose(fid);

if ~isempty(simPart)                           
    fid = fopen(sumFile,'a'); fprintf(fid,'\n%s', simPart); fclose(fid);
end
disp(fileread(sumFile));
